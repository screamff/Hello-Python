from distutils.core import setup

setup(name="cat_dog",
      version="1.0",
      description="测试安装模块",
      author="nobody",
      author_email="cat_dog@cat.com",
      py_modules=["cat_dog.my_cat",
                  "cat_dog.my_dog"])

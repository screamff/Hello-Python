# coding:utf-8
def say_hello():
    print("wangwangwang")


class Dog(object):

    def __init__(self):
        self.name = "corgi"

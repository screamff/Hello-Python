# coding:utf-8
def say_hello():
    print("miaomiaomiao")


class Cat(object):

    def __init__(self):
        self.name = "shorthair"
